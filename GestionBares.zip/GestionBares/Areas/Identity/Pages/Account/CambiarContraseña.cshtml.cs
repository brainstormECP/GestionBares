﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text.Encodings.Web;
using System.Threading.Tasks;
using GestionBares.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.UI.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;

namespace GestionBares.Areas.Identity.Pages.Account
{
    [AllowAnonymous]
    public class CambiarPasswordModel : PageModel
    {
        private readonly SignInManager<Usuario> _signInManager;
        private readonly UserManager<Usuario> _userManager;
        private readonly ILogger<Usuario> _logger;

        public CambiarPasswordModel(
            UserManager<Usuario> userManager,
            SignInManager<Usuario> signInManager,
            ILogger<Usuario> logger)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _logger = logger;
        }

        [BindProperty]
        public InputModel Input { get; set; }

        public string ReturnUrl { get; set; }

        public class InputModel
        {
            [Required]
            [StringLength(100, ErrorMessage = "La {0} debe tener al menos {2} y como maximo {1} caracteres..", MinimumLength = 6)]
            [DataType(DataType.Password)]
            [Display(Name = "Contraseña actual")]
            public string CurrentPassword { get; set; }

            [Required]
            [StringLength(100, ErrorMessage = "La {0} debe tener al menos {2} y como maximo {1} caracteres.", MinimumLength = 6)]
            [DataType(DataType.Password)]
            [Display(Name = "Contraseña nueva")]
            public string Password { get; set; }

            [DataType(DataType.Password)]
            [Display(Name = "Confirmar contraseña nueva")]
            [Compare("Password", ErrorMessage = "La {0} debe coincidir con {1}.")]
            public string ConfirmPassword { get; set; }
        }

        public void OnGet(string returnUrl = null)
        {
            ReturnUrl = returnUrl;
        }

        public async Task<IActionResult> OnPostAsync(string returnUrl = null)
        {
            returnUrl = returnUrl ?? Url.Content("~/");
            if (ModelState.IsValid)
            {
                var user = await _userManager.FindByNameAsync(User.Identity.Name);
                if (user != null)
                {
                    _logger.LogInformation($"El usuario {User.Identity.Name} cambio su contraseña.");
                    var result = await _userManager.ChangePasswordAsync(user, Input.CurrentPassword, Input.Password);
                    if (result.Succeeded)
                    {
                        TempData["exito"] = "Contraseña cambiada correctamente";
                        return LocalRedirect(returnUrl);
                    }
                    foreach (var error in result.Errors)
                    {
                        ModelState.AddModelError(string.Empty, error.Description);
                    }
                }
            }
            // If we got this far, something failed, redisplay form
            return Page();
        }
    }
}
