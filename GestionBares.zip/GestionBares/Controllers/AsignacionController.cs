﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using GestionBares.Data;
using GestionBares.Models;
using Microsoft.AspNetCore.Authorization;
using GestionBares.Utils;
using GestionBares.ViewModels;
using System.Drawing;

namespace GestionBares.Controllers
{
    [Authorize]
    public class AsignacionController : Controller
    {
        private readonly AmasBDbContext _context;

        public AsignacionController(AmasBDbContext context)
        {
            _context = context;
        }

        public List<VentasDependientesPorBar> CrearTabla(List<Dependiente> _dependientes, List<Bar> _bares, DateTime FechaInicio, DateTime FechaFinal)
        {
            var Dependientes = _dependientes;
            var Bares = _bares;
            var COE = _context.ControlesDeExistenciasVenta.Include(c => c.Detalles).ToList();

            List<VentasDependientesPorBar> ListaVentasDependientesPorBar = new List<VentasDependientesPorBar>();

            foreach (var itemDependiente in Dependientes)
            {
                if (_context.Turnos.Any(c => c.DependienteId == itemDependiente.Id
                && c.FechaInicio >= FechaInicio
                && c.FechaFin <= FechaFinal))
                {


                    VentasDependientesPorBar vp = new VentasDependientesPorBar();
                    vp.DependienteId = itemDependiente.Id;
                    vp.DependienteNombre = itemDependiente.Nombres;

                    foreach (var item in Bares)
                        vp.VentasPorBares.Add(new VentasPorBar() { BarId = item.Id, BarNombre = item.Nombre, PromedioVentasPorTurno = 0 });

                    foreach (var itemTurno in _context.Turnos.Include(c => c.Bar).Where(c => c.DependienteId == itemDependiente.Id &&
                        c.FechaInicio >= FechaInicio &&
                        c.FechaFin <= FechaFinal))
                    {

                        if (Bares.Any(c => c.Id == itemTurno.BarId))

                            foreach (var itemCOE in COE.Where(c => c.TurnoId == itemTurno.Id))
                            {

                                foreach (var itemDetalleCOE in itemCOE.Detalles.Where(c => c.Consumo != 0))
                                {


                                    vp.VentasPorBares.Where(c => c.BarId == itemTurno.BarId).Single().PromedioVentasPorTurno += itemDetalleCOE.Consumo;

                                }
                            }

                    }


                    ListaVentasDependientesPorBar.Add(vp);
                }
            }

            return (ListaVentasDependientesPorBar);
        }

        public List<VentasDependientesPorBar> CrearTablaRazon(List<CheckedDependientes> _dependientes, List<CheckedTurno> _bares, DateTime FechaInicio, DateTime FechaFinal)
        {


            List<Dependiente> Dependientes = new List<Dependiente>();

            foreach (var item in _context.Dependientes.OrderBy(c => c.Id).ToList())
            {
                if (_dependientes.Any(c => c.DependienteId == item.Id && c.Checked == true))
                    Dependientes.Add(item);
            }

            List<Bar> Bares = new List<Bar>();

            foreach (var item in _context.Bares.OrderBy(c => c.Id).ToList())
            {
                if (_bares.Any(c => c.BarId == item.Id && c.Checked == true))
                    Bares.Add(item);
            }

            var COE = _context.ControlesDeExistenciasVenta.Include(c => c.Detalles).ToList();
            List<VentasDependientesPorBar> ListaVentasDependientesPorBar = new List<VentasDependientesPorBar>();

            foreach (var itemDependiente in Dependientes)
            {
                if (_context.Turnos.Any(c => c.DependienteId == itemDependiente.Id
                && c.FechaInicio >= FechaInicio
                && c.FechaFin <= FechaFinal))
                {
                    VentasDependientesPorBar vp = new VentasDependientesPorBar();
                    vp.DependienteId = itemDependiente.Id;
                    vp.DependienteNombre = itemDependiente.Nombres;

                    foreach (var item in Bares)
                        vp.VentasPorBares.Add(new VentasPorBar() { BarId = item.Id, BarNombre = item.Nombre, PromedioVentasPorTurno = 0 });

                    foreach (var itemTurno in _context.Turnos.Include(c => c.Bar)
                    .Where(c => c.DependienteId == itemDependiente.Id &&
                    c.FechaInicio >= FechaInicio &&
                    c.FechaFin <= FechaFinal))
                    {
                        if (Bares.Any(c => c.Id == itemTurno.BarId))
                        {

                            int CantidadTurnos = _context.Turnos.Where(c => c.DependienteId == itemDependiente.Id && c.BarId == itemTurno.BarId).Count();

                            foreach (var itemCOE in COE.Where(c => c.TurnoId == itemTurno.Id))
                            {

                                foreach (var itemDetalleCOE in itemCOE.Detalles.Where(c => c.Consumo != 0))
                                {
                                    double valor = 0 + (double)itemDetalleCOE.Consumo / (double)CantidadTurnos * 100;
                                    int valorEntero = (int)valor;

                                    vp.VentasPorBares.Where(c => c.BarId == itemTurno.BarId)
                                        .Single().PromedioVentasPorTurno += valorEntero;

                                }
                            }
                        }
                    }
                    ListaVentasDependientesPorBar.Add(vp);

                }
            }

            return (ListaVentasDependientesPorBar);
        }

        //asigancion
        public IActionResult Asignacion()
        {
            ViewData["Dependientes"] = _context.Dependientes.OrderBy(c => c.Id).ToList();
            var checkedDependientes = _context.Dependientes.ToList().Select(d => new CheckedDependientes() { Checked = true, Dependiente = d, DependienteId = d.Id }).ToList();
            ViewData["CheckedDependiente"] = checkedDependientes;
            var checkedTurnos = _context.Bares.ToList().Select(b => new CheckedTurno() { Checked = true, Bar = b, BarId = b.Id }).ToList();
            ViewData["CheckedBares"] = checkedTurnos;
            ViewData["Bares"] = _context.Bares.OrderBy(c => c.Id).ToList();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Asignacion([Bind("CheckedDependientes, CheckedTurnos, FechaInicio, FechaFinal")] SeleccionarAsignacionVM seleccionarAsignacionVM)
        {



            List<Dependiente> Dependientes = new List<Dependiente>();

            foreach (var item in _context.Dependientes.OrderBy(c => c.Id).ToList())
            {
                if (seleccionarAsignacionVM.CheckedDependientes.Any(c => c.DependienteId == item.Id && c.Checked == true))
                    Dependientes.Add(item);
            }

            List<Bar> Bares = new List<Bar>();

            foreach (var item in _context.Bares.OrderBy(c => c.Id).ToList())
            {
                if (seleccionarAsignacionVM.CheckedTurnos.Any(c => c.BarId == item.Id && c.Checked == true))
                    Bares.Add(item);
            }

            var COE = _context.ControlesDeExistenciasVenta.Include(c => c.Detalles).ToList();
            List<VentasDependientesPorBar> ListaVentasDependientesPorBar = new List<VentasDependientesPorBar>();

            foreach (var itemDependiente in Dependientes)
            {
                if (_context.Turnos.Any(c => c.DependienteId == itemDependiente.Id
                && c.FechaInicio >= seleccionarAsignacionVM.FechaInicio
                && c.FechaFin <= seleccionarAsignacionVM.FechaFinal))
                {
                    VentasDependientesPorBar vp = new VentasDependientesPorBar();
                    vp.DependienteId = itemDependiente.Id;
                    vp.DependienteNombre = itemDependiente.Nombres;

                    foreach (var item in Bares)
                        vp.VentasPorBares.Add(new VentasPorBar() { BarId = item.Id, BarNombre = item.Nombre, PromedioVentasPorTurno = 0 });

                    foreach (var itemTurno in _context.Turnos.Include(c => c.Bar)
                    .Where(c => c.DependienteId == itemDependiente.Id &&
                    c.FechaInicio >= seleccionarAsignacionVM.FechaInicio &&
                    c.FechaFin <= seleccionarAsignacionVM.FechaFinal))
                    {
                        if (Bares.Any(c => c.Id == itemTurno.BarId))
                        {

                            int CantidadTurnos = _context.Turnos.Where(c => c.DependienteId == itemDependiente.Id && c.BarId == itemTurno.BarId).Count();

                            foreach (var itemCOE in COE.Where(c => c.TurnoId == itemTurno.Id))
                            {

                                foreach (var itemDetalleCOE in itemCOE.Detalles.Where(c => c.Consumo != 0))
                                {
                                    double valor = 0 + (double)itemDetalleCOE.Consumo / (double)CantidadTurnos * 100;
                                    double valorEntero = (double)valor;

                                    vp.VentasPorBares.Where(c => c.BarId == itemTurno.BarId)
                                        .Single().PromedioVentasPorTurno += valorEntero;

                                }
                            }
                        }
                    }
                    ListaVentasDependientesPorBar.Add(vp);

                }
            }

            if (ListaVentasDependientesPorBar.Any())
            {


                //Convertinedo en un array de 2 dimensiones
                double[,] Tabla = new double[ListaVentasDependientesPorBar.Count, Bares.Count];

                for (int f = 0; f < Tabla.GetLength(0); f++)
                {
                    for (int c = 0; c < Tabla.GetLength(1); c++)
                    {

                        Tabla[f, c] = ListaVentasDependientesPorBar[f].VentasPorBares[c].PromedioVentasPorTurno;
                    }
                }

                //Balancenado el Problema
                if (Tabla.GetLength(0) > Tabla.GetLength(1))
                {
                    int Diferencia = Tabla.GetLength(0) - Tabla.GetLength(1);
                    double[,] NuevaTabla = new double[Tabla.GetLength(0), Tabla.GetLength(0)];

                    for (int f = 0; f < Tabla.GetLength(0); f++)
                    {
                        for (int c = 0; c < Tabla.GetLength(1); c++)
                        {
                            NuevaTabla[f, c] = Tabla[f, c];
                        }
                    }
                    Tabla = NuevaTabla;
                    //Agregando Bares ficticios
                    for (int x = 0; x < Diferencia; x++)
                    {
                        Bares.Add(new Bar() { Nombre = "Ficticio010101" });
                    }
                }


                int[] AsginacionOptima = HungarianAlgorithm.FindAssignments(Tabla, true);
                List<string> Asignaciones = new List<string>();
                for (int x = 0; x < AsginacionOptima.Count(); x++)
                {
                    if (!(Bares[AsginacionOptima[x]].Nombre == "Ficticio010101"))
                        Asignaciones.Add(Dependientes[x].Nombres + " --> " + Bares[AsginacionOptima[x]].Nombre);
                }

                ViewData["AsignacionOptima"] = Asignaciones;

            }
            else
                ViewData["AsignacionOptima"] = new List<string>() { "No existe Turnos para esta fecha" };

            List<CheckedDependientes> checkedDependientes = new List<CheckedDependientes>();
            foreach (var item in _context.Dependientes.ToList())
                checkedDependientes.Add(new CheckedDependientes() { Checked = true, Dependiente = item, DependienteId = item.Id });

            ViewData["CheckedDependiente"] = checkedDependientes;

            List<CheckedTurno> checkedTurnos = new List<CheckedTurno>();
            foreach (var item in _context.Bares.ToList())
                checkedTurnos.Add(new CheckedTurno() { Checked = true, Bar = item, BarId = item.Id });

            ViewData["CheckedBares"] = checkedTurnos;

            List<Bar> BaresParaViewbag = new List<Bar>();
            foreach (var item in seleccionarAsignacionVM.CheckedTurnos.Where(c => c.Checked == true))
                BaresParaViewbag.Add(_context.Bares.OrderBy(c => c.Id).Where(c => c.Id == item.BarId).Single());

            ViewData["Bares"] = BaresParaViewbag;


            List<Dependiente> DependientesParaViewbag = new List<Dependiente>();
            foreach (var item in seleccionarAsignacionVM.CheckedDependientes.Where(c => c.Checked == true))
                DependientesParaViewbag.Add(_context.Dependientes.OrderBy(c => c.Id).Where(c => c.Id == item.DependienteId).Single());

            List<VentasDependientesPorBar> TablaTotal = CrearTabla(DependientesParaViewbag, BaresParaViewbag, seleccionarAsignacionVM.FechaInicio, seleccionarAsignacionVM.FechaFinal);

            ViewData["CrearTablaRazon"] = CrearTablaRazon(seleccionarAsignacionVM.CheckedDependientes, seleccionarAsignacionVM.CheckedTurnos, seleccionarAsignacionVM.FechaInicio, seleccionarAsignacionVM.FechaFinal);

            return View("Asignacion", TablaTotal);

        }

        #region Helpers
        private List<VentasDependientesPorBar> BuscarVentas(List<int> dependientesId, List<int> baresId, DateTime fechaInicio, DateTime fechaFinal)
        {
            var existenciaService = new ExistenciasService(_context);
            var turnosEnPeriodo = _context.Turnos
                .Include(c => c.Bar)
                .Where(c => dependientesId.Any(d => d == c.DependienteId) &&
                    baresId.Any(b => b == c.BarId) &&
                    c.FechaInicio >= fechaInicio &&
                    c.FechaFin <= fechaFinal)
                .ToList();
            if (turnosEnPeriodo == null) turnosEnPeriodo = new List<Turno>();
            var ventas = turnosEnPeriodo.Select(c => new
            {
                Fecha = c.FechaInicio,
                TurnoId = c.Id,
                BarId = c.BarId,
                DependienteId = c.DependienteId,
                Ventas = existenciaService.ExistenciaVentaDeBarPorTurno(c.Id).Sum(e => e.Consumo * (double)e.Precio),
            }).ToList();
            var bares = _context.Set<Bar>().Select(b => new { Id = b.Id, Nombre = b.Nombre }).ToList();
            var dependientes = _context.Set<Dependiente>().Select(b => new { Id = b.Id, Nombre = b.NombreCompleto }).ToList();
            var ventasDependientesPorBar = ventas.GroupBy(v => v.DependienteId).Select(v => new VentasDependientesPorBar
            {
                DependienteId = v.Key,
                DependienteNombre = dependientes.FirstOrDefault(d => d.Id == v.Key).Nombre,
                VentasPorBares = v.GroupBy(b => b.BarId).Select(b => new VentasPorBar
                {
                    BarId = b.Key,
                    BarNombre = bares.FirstOrDefault(s => s.Id == b.Key).Nombre,
                    PromedioVentasPorTurno = b.Sum(p => p.Ventas) / b.Count(),
                }).ToList(),
            }).ToList();
            return ventasDependientesPorBar;
        }
        #endregion
    }
}
