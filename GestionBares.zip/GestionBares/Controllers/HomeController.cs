﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using GestionBares.Models;
using Microsoft.AspNetCore.Authorization;
using GestionBares.Data;
using Microsoft.EntityFrameworkCore;
using GestionBares.Utils;
using GestionBares.Models.AlmacenModels;

namespace GestionBares.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {
        private readonly ApplicationDbContext _db;
        private readonly AlmacenDbContext _almacen;

        public HomeController(ApplicationDbContext context, AlmacenDbContext almacen)
        {
            _db = context;
            _almacen = almacen;
        }
        public IActionResult Index()
        {
            if(!_almacen.Ocupacion.Any())
            {
                DateTime Fecha = new DateTime(2019, 1, 1);
                
                Random random = new Random();
                for(int x = 0; x <365; x++)
                {
                    Fecha = Fecha.AddDays(1);
                    _almacen.Ocupacion.Add(new Ocupacion() { OcupacionDelDia = random.Next(500, 800), Fecha = Fecha, });
                }
                _almacen.SaveChanges();

            }

            if (User.IsInRole(DefinicionRoles.Dependiente))
            {
                var dependiente = _db.Set<Dependiente>().SingleOrDefault(u => u.Usuario.UserName == User.Identity.Name);
                if (!_db.Set<Turno>().Any(t => t.DependienteId == dependiente.Id && t.Activo))
                {
                    ViewBag.Turno = "No existe un turno iniciado, inicie uno para comenzar a trabajar.";
                }
                else
                {
                    var turno = _db.Set<Turno>()
                        .Include(t => t.Bar)
                        .SingleOrDefault(t => t.DependienteId == dependiente.Id && t.Activo);
                    ViewBag.Turno = $"Usted tiene un turno abierto en el bar {turno.Bar.Nombre} con fecha {turno.FechaInicio.ToShortDateString()}.";
                }
            }
            return View();
        }



        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            //Random random = new Random();

            //for(int x = 0; x < 200; x++)
            //{
            //    _db.Productos.Add(new Producto() { Nombre = random.Next(20).ToString(), Codigo = random.Next(0, 20).ToString(), Costo = random.Next(100), Familia = _db.FamiliasDeProductos.Single(c => c.Id == 1), Precio = random.Next(100), UnidadId = 1, FamiliaId = 1, Unidad = _db.UnidadesDeMedidas.Single(c => c.Id == 1) });
            //}
            //_db.SaveChanges();


            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
