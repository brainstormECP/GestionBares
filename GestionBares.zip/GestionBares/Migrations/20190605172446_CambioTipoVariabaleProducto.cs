﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace GestionBares.Migrations
{
    public partial class CambioTipoVariabaleProducto : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            

            migrationBuilder.AlterColumn<double>(
                name: "Costo",
                table: "Productos",
                nullable: false,
                oldClrType: typeof(decimal));

            migrationBuilder.AlterColumn<double>(
                name: "Costo",
                table: "DetallesControlesDeExistenciasVenta",
                nullable: false,
                oldClrType: typeof(decimal));

            migrationBuilder.AlterColumn<double>(
                name: "Costo",
                table: "DetallesControlesDeExistencias",
                nullable: false,
                oldClrType: typeof(decimal));

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "1",
                column: "ConcurrencyStamp",
                value: "0e9bec35-9d27-4b7c-8090-8c6b3e87c17c");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "2",
                column: "ConcurrencyStamp",
                value: "04915541-53a4-4e0f-b0a5-8e64e19fca1d");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "3",
                column: "ConcurrencyStamp",
                value: "9b47b0b9-f008-4860-a53f-b01586ffec02");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "4",
                column: "ConcurrencyStamp",
                value: "dd07cdf7-95f5-405c-87c9-3abe1f853af6");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "5",
                column: "ConcurrencyStamp",
                value: "6ba211c4-c4cf-4c53-a46c-6d1c1708704f");

            
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Traslados_Turnos_DestinoId",
                table: "Traslados");

            migrationBuilder.DropForeignKey(
                name: "FK_TrasladosVenta_Turnos_DestinoId",
                table: "TrasladosVenta");

            migrationBuilder.AlterColumn<decimal>(
                name: "Costo",
                table: "Productos",
                nullable: false,
                oldClrType: typeof(double));

            migrationBuilder.AlterColumn<decimal>(
                name: "Costo",
                table: "DetallesControlesDeExistenciasVenta",
                nullable: false,
                oldClrType: typeof(double));

            migrationBuilder.AlterColumn<decimal>(
                name: "Costo",
                table: "DetallesControlesDeExistencias",
                nullable: false,
                oldClrType: typeof(double));

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "1",
                column: "ConcurrencyStamp",
                value: "2df8339c-b2bb-4fbf-8b24-7d7f7ec1ec45");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "2",
                column: "ConcurrencyStamp",
                value: "0617d4b4-2cce-41d1-94f0-a2f730de3782");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "3",
                column: "ConcurrencyStamp",
                value: "fd844024-c046-4d11-a97f-fc277d6d9551");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "4",
                column: "ConcurrencyStamp",
                value: "d0961d8c-72e1-4c8c-ac9a-79287305fa95");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "5",
                column: "ConcurrencyStamp",
                value: "bce34941-3d6b-4bf8-8898-5254c34a9cb1");

            migrationBuilder.AddForeignKey(
                name: "FK_Traslados_Bares_DestinoId",
                table: "Traslados",
                column: "DestinoId",
                principalTable: "Bares",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_TrasladosVenta_Bares_DestinoId",
                table: "TrasladosVenta",
                column: "DestinoId",
                principalTable: "Bares",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
