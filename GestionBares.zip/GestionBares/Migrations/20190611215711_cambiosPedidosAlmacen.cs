﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace GestionBares.Migrations
{
    public partial class cambiosPedidosAlmacen : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "DetallesPedidosDeAlmacen");

            migrationBuilder.AddColumn<bool>(
                name: "Atendido",
                table: "PedidosDeAlmacen",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<double>(
                name: "Cantidad",
                table: "PedidosDeAlmacen",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<int>(
                name: "ProductoId",
                table: "PedidosDeAlmacen",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "1",
                column: "ConcurrencyStamp",
                value: "ac4c2a87-9f38-4897-86bf-9518c29e3be6");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "2",
                column: "ConcurrencyStamp",
                value: "9d37239a-0b98-49dd-a85d-a46e5d07b058");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "3",
                column: "ConcurrencyStamp",
                value: "0317d899-d899-4aeb-abc3-6712c601b70c");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "4",
                column: "ConcurrencyStamp",
                value: "e3e8018d-b093-44b7-b417-dd668f69c28c");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "5",
                column: "ConcurrencyStamp",
                value: "964789d7-414f-4ba0-a7f0-0357fb4995cb");

            migrationBuilder.CreateIndex(
                name: "IX_PedidosDeAlmacen_ProductoId",
                table: "PedidosDeAlmacen",
                column: "ProductoId");

            migrationBuilder.AddForeignKey(
                name: "FK_PedidosDeAlmacen_Productos_ProductoId",
                table: "PedidosDeAlmacen",
                column: "ProductoId",
                principalTable: "Productos",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_PedidosDeAlmacen_Productos_ProductoId",
                table: "PedidosDeAlmacen");

            migrationBuilder.DropIndex(
                name: "IX_PedidosDeAlmacen_ProductoId",
                table: "PedidosDeAlmacen");

            migrationBuilder.DropColumn(
                name: "Atendido",
                table: "PedidosDeAlmacen");

            migrationBuilder.DropColumn(
                name: "Cantidad",
                table: "PedidosDeAlmacen");

            migrationBuilder.DropColumn(
                name: "ProductoId",
                table: "PedidosDeAlmacen");

            migrationBuilder.CreateTable(
                name: "DetallesPedidosDeAlmacen",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Atendido = table.Column<bool>(nullable: false),
                    Cantidad = table.Column<double>(nullable: false),
                    PedidoId = table.Column<int>(nullable: false),
                    ProductoId = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DetallesPedidosDeAlmacen", x => x.Id);
                    table.ForeignKey(
                        name: "FK_DetallesPedidosDeAlmacen_PedidosDeAlmacen_PedidoId",
                        column: x => x.PedidoId,
                        principalTable: "PedidosDeAlmacen",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_DetallesPedidosDeAlmacen_Productos_ProductoId",
                        column: x => x.ProductoId,
                        principalTable: "Productos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "1",
                column: "ConcurrencyStamp",
                value: "9aee2a16-0373-4091-87b2-4a040df4f419");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "2",
                column: "ConcurrencyStamp",
                value: "2d0f2510-430c-4a12-a72d-d4853916aeb5");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "3",
                column: "ConcurrencyStamp",
                value: "58bf7f5e-d1ba-412c-8b57-b0ab5d5514c1");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "4",
                column: "ConcurrencyStamp",
                value: "f78ebfc8-32bd-4fcf-9a71-6962ac3c6334");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "5",
                column: "ConcurrencyStamp",
                value: "d685b4ea-c740-4a32-adca-749569bb91ee");

            migrationBuilder.CreateIndex(
                name: "IX_DetallesPedidosDeAlmacen_PedidoId",
                table: "DetallesPedidosDeAlmacen",
                column: "PedidoId");

            migrationBuilder.CreateIndex(
                name: "IX_DetallesPedidosDeAlmacen_ProductoId",
                table: "DetallesPedidosDeAlmacen",
                column: "ProductoId");
        }
    }
}
