namespace GestionBares.Models.AlmacenModels
{
    public class Existencia
    {
        public int Id {get;set;}
        public string CodigoProducto { get; set; }
        public double Cantidad { get; set; }
    }
}