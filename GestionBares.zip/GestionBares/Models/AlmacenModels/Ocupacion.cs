﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GestionBares.Models.AlmacenModels
{
    public class Ocupacion
    {
        public int Id { get; set; }
        public DateTime Fecha { get; set; }
        public int OcupacionDelDia { get; set; }
    }
}
