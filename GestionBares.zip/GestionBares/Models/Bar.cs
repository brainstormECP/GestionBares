using System.ComponentModel.DataAnnotations;

namespace GestionBares.Models
{
    public class Bar
    {
        public int Id { get; set; }        
        [Required(ErrorMessage = "Este campo es obligatorio")]
        [DataType(DataType.Text)]
        public string Nombre { get; set; }
        public bool Activo { get; set; }
        [Display(Name = "Limite de Consumo")]
        [Required(ErrorMessage = "Este campo es obligatorio")]        
        [RegularExpression("([0-9.]+)", ErrorMessage = "Por favor entre un numero valido")]
        public double IndiceCosto { get; set; }
    }
}