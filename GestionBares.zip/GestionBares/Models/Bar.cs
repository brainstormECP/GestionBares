using System.ComponentModel.DataAnnotations;

namespace GestionBares.Models
{
    public class Bar
    {
        public int Id { get; set; }
        [Required(ErrorMessage = "El campo {0} es obligatorio")]
        public string Nombre { get; set; }
        public bool Activo { get; set; }
        [Display(Name = "Limite de Consumo")]
        [Required(ErrorMessage = "El campo {0} es obligatorio")]
        public double IndiceCosto { get; set; }
    }
}