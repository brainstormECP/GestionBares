using System.ComponentModel.DataAnnotations;

namespace GestionBares.Models
{
    public class FamiliaDeProducto
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Este campo es obligatorio")]
        [DataType(DataType.Text)]
        public string Nombre { get; set; }
    }
}