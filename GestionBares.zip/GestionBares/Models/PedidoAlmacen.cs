using System;
using System.ComponentModel.DataAnnotations;

namespace GestionBares.Models
{
    public class PedidoAlmacen
    {
        public int Id { get; set; }
        [Display(Name = "Turno")]
        public int TurnoId { get; set; }
        public virtual Turno Turno { get; set; }
        public DateTime Fecha { get; set; }
        public DateTime? FechaAprobacion { get; set; }

        [Display(Name = "Producto")]
        public int ProductoId { get; set; }
        public virtual Producto Producto { get; set; }
        [Required(ErrorMessage = "El campo {0} es obligatorio")]
        public double Cantidad { get; set; }
        public bool Atendido { get; set; }
    }
}