using System.ComponentModel.DataAnnotations;

namespace GestionBares.Models
{
    public class Producto
    {
        public int Id { get; set; }
        [Required(ErrorMessage = "Este campo es obligatorio")]
        [DataType(DataType.Text)]
        public string Codigo { get; set; }
        [Required(ErrorMessage = "Este campo es obligatorio")]
        [DataType(DataType.Text)]
        public string Nombre { get; set; }
        [Display(Name = "Unidad de Medida")]
        public int UnidadId { get; set; }
        public virtual UnidadDeMedida Unidad { get; set; }
        [Display(Name = "Familia")]
        public int FamiliaId { get; set; }
        public virtual FamiliaDeProducto Familia { get; set; }
        [Required(ErrorMessage = "Este campo es obligatorio")]
        [RegularExpression("([0-9.]+)", ErrorMessage = "Por favor entre un numero valido")]
        public decimal Precio { get; set; }
        [Required(ErrorMessage = "Este campo es obligatorio")]
        [RegularExpression("([0-9.]+)", ErrorMessage = "Por favor entre un numero valido")]
        public double Costo { get; set; }
        public bool Activo { get; set; }
    }
}