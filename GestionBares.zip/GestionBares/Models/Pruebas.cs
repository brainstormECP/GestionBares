﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GestionBares.Models
{
    public class Pruebas
    {
        public int CantidadDeTurnos { get; set; }
        public List<int> Dependientes { get; set; }
        public List<int> Bares { get; set; }
        public DateTime FechaInicio { get; set; }
        public DateTime FechaFin { get; set; }
        public double ConsumoMinimo { get; set; }
        public double ConsumoMaximo { get; set; }
        public double VentasMinimo { get; set; }
        public double VentasMaximo { get; set; }


        public Pruebas()
        {
            Dependientes = new List<int>();
            Bares = new List<int>();
        }

    }
}
