﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace GestionBares.ViewModels
{
    public class ReporteIPV
    {

        public string Codigo { get; set; }
        public string Descripcion { get; set; }
        public double Costo { get; set; }
        public decimal Precio { get; set; }
        public double Inicio { get; set; }
        public double Entradas { get; set; }
        [Display(Name = "Traslados +")]
        public double TrasladosPositivos { get; set; }
        [Display(Name = "Traslados -")]
        public double TrasladosNegativos { get; set; }
        public double Consumo { get; set; }
        public double Final { get; set; }
    }
}
