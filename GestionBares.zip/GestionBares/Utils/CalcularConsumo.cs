﻿using GestionBares.Data;
using GestionBares.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GestionBares.Utils
{
    public class CalcularConsumo
    {
        private readonly DbContext _context;

        public CalcularConsumo(DbContext context)
        {
            _context = context;
        }

        public List<DetalleControlExistencia> Consumo(int ControlExistenciaId)
        {


            var turno = _context.Set<Turno>().SingleOrDefault(c => c.Id ==
            _context.Set<ControlExistencia>().SingleOrDefault
            (b => b.Id == ControlExistenciaId).TurnoId);

            Turno TurnoAnterior;
            List<DetalleControlExistencia> DetallesAnterior = new List<DetalleControlExistencia>();

            if (_context.Set<Turno>().Any((c => c.BarId == turno.BarId && c.Id != turno.Id)))
            {
                TurnoAnterior = _context.Set<Turno>().OrderBy(c => c.FechaFin).Where(c => c.BarId == turno.BarId && c.Id != turno.Id).Last();
                DetallesAnterior = _context.Set<DetalleControlExistencia>()
                    .Where(c => c.ControlId == _context.Set<ControlExistencia>()
                    .SingleOrDefault(i => i.TurnoId == TurnoAnterior.Id).Id).ToList();
            }
            else
            {
                foreach (var item in _context.Set<DetalleControlExistencia>()
                    .Where(c => c.ControlId == _context.Set<ControlExistencia>()
                    .SingleOrDefault(i => i.TurnoId == turno.Id).Id).ToList())
                    DetallesAnterior.Add(new DetalleControlExistencia()
                    {
                        Cantidad = 0,
                        Control = item.Control,
                        ControlId = item.ControlId,
                        Costo = item.Costo,
                        Producto = item.Producto,
                        ProductoId = item.ProductoId
                    });
            }

            var Entradas = _context.Set<EntregaDeAlmacen>().Where(c => c.TurnoId == turno.Id).ToList();
            var Traslados = _context.Set<Traslado>().Where(c => c.TurnoId == turno.Id && c.Aprobado).ToList();
            var TransladosARx = _context.Set<Traslado>().Where(c => c.DestinoId == turno.Id && c.Aprobado).ToList();
            var Detalles = _context.Set<DetalleControlExistencia>()
                .Where(c => c.ControlId == _context.Set<ControlExistencia>()
                .SingleOrDefault(i => i.TurnoId == turno.Id).Id).ToList();

            foreach (var item in Detalles)
            {
                double contadorEntradas = 0;
                double contadorTraslados = 0;
                double contadorTrasladosARx = 0;
                foreach (var entradas in Entradas.Where(c => c.ProductoId == item.ProductoId).ToList())
                {
                    contadorEntradas += entradas.Cantidad;
                }
                foreach (var traslados in Traslados.Where(c => c.ProductoId == item.ProductoId).ToList())
                {
                    contadorTraslados += traslados.Cantidad;
                }
                foreach (var trasladosARx in TransladosARx.Where(c => c.ProductoId == item.ProductoId).ToList())
                {
                    contadorTrasladosARx += trasladosARx.Cantidad;
                }

                item.Consumo = DetallesAnterior.SingleOrDefault(c => c.ProductoId == item.ProductoId).Cantidad + contadorEntradas + contadorTrasladosARx - contadorTraslados - item.Cantidad;


            }

            return Detalles;
        }

        public List<DetalleControlExistenciaVenta> ConsumoVentas(int ControlExistenciaId)
        {


            var turno = _context.Set<Turno>().SingleOrDefault(c => c.Id ==
            _context.Set<ControlExistenciaVenta>().SingleOrDefault
            (b => b.Id == ControlExistenciaId).TurnoId);

            Turno TurnoAnterior;
            List<DetalleControlExistenciaVenta> DetallesAnterior = new List<DetalleControlExistenciaVenta>();

            if (_context.Set<Turno>().Any((c => c.BarId == turno.BarId && c.Id != turno.Id)))
            {
                TurnoAnterior = _context.Set<Turno>().OrderBy(c => c.FechaFin).Where(c => c.BarId == turno.BarId && c.Id != turno.Id).Last();
                DetallesAnterior = _context.Set<DetalleControlExistenciaVenta>()
                    .Where(c => c.ControlId == _context.Set<ControlExistenciaVenta>()
                    .SingleOrDefault(i => i.TurnoId == TurnoAnterior.Id).Id).ToList();
            }
            else
            {
                foreach (var item in _context.Set<DetalleControlExistenciaVenta>()
                    .Where(c => c.ControlId == _context.Set<ControlExistenciaVenta>()
                    .SingleOrDefault(i => i.TurnoId == turno.Id).Id).ToList())
                    DetallesAnterior.Add(new DetalleControlExistenciaVenta()
                    {
                        Cantidad = 0,
                        Control = item.Control,
                        ControlId = item.ControlId,
                        Costo = item.Costo,
                        Producto = item.Producto,
                        ProductoId = item.ProductoId
                    });
            }

            var Entradas = _context.Set<EntregaDeAlmacenVenta>().Where(c => c.TurnoId == turno.Id).ToList();
            var Traslados = _context.Set<TrasladoVenta>().Where(c => c.TurnoId == turno.Id && c.Aprobado).ToList();
            var TransladosARx = _context.Set<TrasladoVenta>().Where(c => c.DestinoId == turno.Id && c.Aprobado).ToList();
            var Detalles = _context.Set<DetalleControlExistenciaVenta>()
                .Where(c => c.ControlId == _context.Set<ControlExistenciaVenta>()
                .SingleOrDefault(i => i.TurnoId == turno.Id).Id).ToList();

            foreach (var item in Detalles)
            {
                double contadorEntradas = 0;
                double contadorTraslados = 0;
                double contadorTrasladosARx = 0;
                foreach (var entradas in Entradas.Where(c => c.ProductoId == item.ProductoId).ToList())
                {
                    contadorEntradas += entradas.Cantidad;
                }
                foreach (var traslados in Traslados.Where(c => c.ProductoId == item.ProductoId).ToList())
                {
                    contadorTraslados += traslados.Cantidad;
                }
                foreach (var trasladosARx in TransladosARx.Where(c => c.ProductoId == item.ProductoId).ToList())
                {
                    contadorTrasladosARx += trasladosARx.Cantidad;
                }

                item.Consumo = DetallesAnterior.SingleOrDefault(c => c.ProductoId == item.ProductoId).Cantidad + contadorEntradas + contadorTrasladosARx - contadorTraslados - item.Cantidad;
            }

            return Detalles;
        }
    }
}
