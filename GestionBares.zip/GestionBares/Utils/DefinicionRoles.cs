namespace GestionBares.Utils
{
    public static class DefinicionRoles
    {
        public const string Administrador = "ADMINISTRADOR";
        public const string Dependiente = "DEPENDIENTE";
        public const string Auditor = "AUDITOR";
        public const string AmasB = "A+B";
        public const string Economia = "ECONOMIA";
    }
}