﻿using GestionBares.Data;
using GestionBares.ViewModels;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GestionBares.Utils
{
    public class DetallesTurnocs
    {
        ApplicationDbContext _context;
        public DetallesTurnocs(ApplicationDbContext context)
        {
            _context = context;
        }



        public List<ReporteIPV> Detalles(int id)
        {

            var Turno = _context.Turnos.Include(c => c.Dependiente).Include(c => c.Bar).SingleOrDefault(c => c.Id == id);
            var ControlExistencia = _context.ControlesDeExistencias.SingleOrDefault(c => c.TurnoId == Turno.Id);

            var DetallesExistencia = _context.DetallesControlesDeExistencias.Include(c => c.Producto)
                .Where(c => c.ControlId == ControlExistencia.Id).ToList();



            List<ReporteIPV> reporteIPVs = new List<ReporteIPV>();
            CalcularConsumo calcularConsumo = new CalcularConsumo(_context);

            foreach (var item in DetallesExistencia)
            {
                reporteIPVs.Add(new ReporteIPV()
                {
                    Codigo = item.Producto.Codigo,
                    Costo = item.Producto.Costo,
                    Descripcion = item.Producto.Nombre,
                    Final = item.Cantidad,
                    Consumo = item.Consumo
                });


                if (_context.Turnos.Any((c => c.BarId == Turno.BarId && c.Id != id && c.Activo == false)))
                {
                    var TurnoAnterior = _context.Turnos.OrderBy(c => c.FechaFin).Where(c => c.BarId == Turno.BarId && c.Id != id && c.Activo == false).Last();
                    var ControlAnterior = _context.ControlesDeExistencias.Where(c => c.TurnoId == TurnoAnterior.Id).Single();

                    if (_context.Turnos.Any(c => c.BarId == Turno.BarId && c.Id != id && c.Activo == false))
                        reporteIPVs.Last().Inicio = _context.DetallesControlesDeExistencias.Where(c => c.ProductoId == item.ProductoId &&
                        c.ControlId == ControlAnterior.Id).Single().Cantidad;
                    else
                        reporteIPVs.Last().Inicio = 0;
                }

                if (_context.EntregasDeAlmacen.Any(c => c.TurnoId == id && c.ProductoId == item.ProductoId))
                    foreach (var Entradas in _context.EntregasDeAlmacen.Where(c => c.TurnoId == id && c.ProductoId == item.ProductoId).ToList())
                        reporteIPVs.Last().Entradas = _context.EntregasDeAlmacen.Where(c => c.TurnoId == id).Single().Cantidad;
                else
                    reporteIPVs.Last().Entradas = 0;
                if (_context.Traslados.Any(c => c.TurnoId == id))
                    foreach (var Traslados in _context.Traslados.Where(c => c.TurnoId == id && c.ProductoId == item.ProductoId).ToList())
                        reporteIPVs.Last().TrasladosNegativos += Traslados.Cantidad;
                else
                    reporteIPVs.Last().TrasladosNegativos = 0;
                if (_context.Traslados.Any(c => c.DestinoId == id && c.ProductoId == item.ProductoId))
                    foreach (var Traslados in _context.Traslados.Where(c => c.DestinoId == id && c.ProductoId == item.ProductoId).ToList())
                        reporteIPVs.Last().TrasladosPositivos += Traslados.Cantidad;
                else
                    reporteIPVs.Last().TrasladosPositivos = 0;
            }

            

            return reporteIPVs;
        }
    }
}
