﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace GestionBares.ViewModels
{
    public class NuevoUsuarioVM
    {
        

        public string Id { get; set; }

        [Required(ErrorMessage = "Este campo es obligatorio")]
        [Display(Name = "Usuario")]
        public string Nombre { get; set; }

        [Required(ErrorMessage = "Este campo es obligatorio")]        
        [RegularExpression(@"^[0-9''-'\s]{11,11}$", ErrorMessage = "El campo CI debe de ser un numero de 11 digitos")]
        public string CI { get; set; }

        public bool Activo { get; set; }

        [Required(ErrorMessage = "Este campo es obligatorio")]        
        [RegularExpression(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[#$^+=!*()@%&]).{8,20}$", ErrorMessage = "El password debde no debe ser mayor de 20 caractéres y debe tener al menos: 8 caractéres Una letra minuscula (a-z), una letra mayuscula (A-Z), un numero (0-9), un caracter especial (Ej. !@#$%^&*) ")]
        [DataType(DataType.Password)]
        [Display(Name = "Contraseña")]
        public string Password { get; set; }

        [Required(ErrorMessage = "Este campo es obligatorio")]
        [DataType(DataType.Password)]
        [Display(Name = "Confirmar contraseña")]
        [Compare("Password", ErrorMessage = "La contraseña y la confirmacion no coinciden.")]
        public string ConfirmPassword { get; set; }

        public List<string> RolesIds { get; set; }

        public NuevoUsuarioVM()
        {
            RolesIds = new List<string>();
        }
    }
}
