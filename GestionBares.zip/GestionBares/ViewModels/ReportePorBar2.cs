﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using GestionBares.Models;

namespace GestionBares.ViewModels
{
    public class ReportePorBar2
    {
        [Display(Name = "Bar")]
        public int BarId { get; set; }
        public Bar Bar { get; set; }
        public int DependienteId { get; set; }
        public Dependiente Dependiente { get; set; }
        public int TurnoId { get; set; }
        public Turno Turno { get; set; }
        public bool EsDeBar { get; set; }
        [Display(Name = "Desde")]
        public DateTime FechaInicio { get; set; }
        [Display(Name = "Hasta")]
        public DateTime FechaFin { get; set; }
        public List<DetalleControlExistencia> DetalleControlExistencias { get; set; }

        public ReportePorBar2()
        {
            DetalleControlExistencias = new List<DetalleControlExistencia>();
        }
    }
}
