﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using GestionBares.Data;
using GestionBares.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Authorization;
using GestionBares.Utils;

namespace GestionBares.Controllers
{
    [Authorize(Roles = DefinicionRoles.Dependiente)]
    public class PedidosController : Controller
    {
        private readonly ApplicationDbContext _context;

        public PedidosController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Traslados
        public IActionResult Index()
        {
            var pedidos = _context.Set<PedidoAlmacen>()
                .Include(t => t.Turno.Bar)
                .Include(t => t.Turno.Dependiente)
                .Include(t => t.Producto.Unidad)
                .Where(p => !p.Atendido)
                .ToList();
            if (User.IsInRole(DefinicionRoles.Dependiente))
            {
                var dependiente = _context.Set<Dependiente>().SingleOrDefault(u => u.Usuario.UserName == User.Identity.Name);
                if (!_context.Set<Turno>().Any(t => t.DependienteId == dependiente.Id && t.Activo))
                {
                    TempData["info"] = "Usted no tiene turno abierto.";
                    return RedirectToAction("Nuevo", "Turno");
                }
                var turno = _context.Set<Turno>().SingleOrDefault(t => t.DependienteId == dependiente.Id && t.Activo);
                pedidos = pedidos.Where(t => t.Turno.BarId == turno.BarId).ToList();
            }
            return View(pedidos);
        }

        // GET: Traslados/Create
        public IActionResult Nuevo()
        {
            var dependiente = _context.Set<Dependiente>().SingleOrDefault(u => u.Usuario.UserName == User.Identity.Name);
            if (!_context.Set<Turno>().Any(t => t.DependienteId == dependiente.Id && t.Activo))
            {
                TempData["info"] = "Usted no tiene turno abierto.";
                return RedirectToAction("Nuevo", "Turno");
            }
            var turno = _context.Set<Turno>().SingleOrDefault(t => t.DependienteId == dependiente.Id && t.Activo);
            ViewBag.TurnoId = turno.Id;
            var productos = _context.Set<Producto>().Where(p => _context.Set<Standard>().Any(s => s.BarId == turno.BarId && s.ProductoId == p.Id) || _context.Set<StandardVenta>().Any(s => s.BarId == turno.BarId && s.ProductoId == p.Id));
            ViewBag.ProductoId = new SelectList(productos, "Id", "Nombre");
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Nuevo(PedidoAlmacen pedido)
        {
            if (ModelState.IsValid)
            {
                pedido.Fecha = DateTime.Now;
                _context.Add(pedido);
                _context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            var dependiente = _context.Set<Dependiente>().SingleOrDefault(u => u.Usuario.UserName == User.Identity.Name);
            if (!_context.Set<Turno>().Any(t => t.DependienteId == dependiente.Id && t.Activo))
            {
                TempData["info"] = "Usted no tiene turno abierto.";
                return RedirectToAction("Nuevo", "Turno");
            }
            var turno = _context.Set<Turno>().SingleOrDefault(t => t.DependienteId == dependiente.Id && t.Activo);
            ViewBag.TurnoId = turno.Id;
            var productos = _context.Set<Producto>().Where(p => _context.Set<Standard>().Any(s => s.BarId == turno.BarId && s.ProductoId == p.Id) || _context.Set<StandardVenta>().Any(s => s.BarId == turno.BarId && s.ProductoId == p.Id));
            ViewBag.ProductoId = new SelectList(productos, "Id", "Nombre");
            return View(pedido);
        }

        // GET: Traslados/Edit/5
        public IActionResult Editar(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var pedido = _context.PedidosDeAlmacen
                .Include(t => t.Turno.Bar)
                .Include(t => t.Turno.Dependiente)
                .Include(t => t.Producto)
                .FirstOrDefault(t => t.Id == id);
            if (pedido == null)
            {
                return NotFound();
            }
            var dependiente = _context.Set<Dependiente>().SingleOrDefault(u => u.Usuario.UserName == User.Identity.Name);
            if (!_context.Set<Turno>().Any(t => t.DependienteId == dependiente.Id && t.Activo))
            {
                TempData["info"] = "Usted no tiene turno abierto.";
                return RedirectToAction("Nuevo", "Turno");
            }
            var turno = _context.Set<Turno>().SingleOrDefault(t => t.DependienteId == dependiente.Id && t.Activo);
            ViewBag.TurnoId = turno.Id;
            var productos = _context.Set<Producto>().Where(p => _context.Set<Standard>().Any(s => s.BarId == turno.BarId && s.ProductoId == p.Id) || _context.Set<StandardVenta>().Any(s => s.BarId == turno.BarId && s.ProductoId == p.Id));
            ViewBag.ProductoId = new SelectList(productos, "Id", "Nombre");
            return View(pedido);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Editar(PedidoAlmacen pedido)
        {
            if (ModelState.IsValid)
            {
                _context.Update(pedido);
                _context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            var dependiente = _context.Set<Dependiente>().SingleOrDefault(u => u.Usuario.UserName == User.Identity.Name);
            if (!_context.Set<Turno>().Any(t => t.DependienteId == dependiente.Id && t.Activo))
            {
                TempData["info"] = "Usted no tiene turno abierto.";
                return RedirectToAction("Nuevo", "Turno");
            }
            var turno = _context.Set<Turno>().SingleOrDefault(t => t.DependienteId == dependiente.Id && t.Activo);
            ViewBag.TurnoId = turno.Id;
            var productos = _context.Set<Producto>().Where(p => _context.Set<Standard>().Any(s => s.BarId == turno.BarId && s.ProductoId == p.Id) || _context.Set<StandardVenta>().Any(s => s.BarId == turno.BarId && s.ProductoId == p.Id));
            ViewBag.ProductoId = new SelectList(productos, "Id", "Nombre");
            return View(pedido);
        }

        public IActionResult Eliminar(int id)
        {
            var pedido = _context.PedidosDeAlmacen.Find(id);
            _context.PedidosDeAlmacen.Remove(pedido);
            try
            {
                _context.SaveChanges();
                TempData["exito"] = "La acción se ha realizado correctamente";
            }
            catch (Exception)
            {
                TempData["error"] = "Error en ralizar esta acción";
                throw;
            }
            return RedirectToAction(nameof(Index));
        }

        public IActionResult Atender(int id)
        {
            var pedidos = _context.Set<PedidoAlmacen>().Where(d => !d.Atendido && d.Id == id);
            foreach (var pedido in pedidos)
            {
                pedido.Atendido = true;
                pedido.FechaAprobacion = DateTime.Now;
            }
            _context.SaveChanges();
            return RedirectToAction(nameof(Index));
        }

        public IActionResult Sugerencias()
        {
            var dependiente = _context.Set<Dependiente>().SingleOrDefault(u => u.Usuario.UserName == User.Identity.Name);
            if (!_context.Set<Turno>().Any(t => t.DependienteId == dependiente.Id && t.Activo))
            {
                TempData["info"] = "Usted no tiene turno abierto.";
                return RedirectToAction("Nuevo", "Turno");
            }
            var turno = _context.Set<Turno>().SingleOrDefault(t => t.DependienteId == dependiente.Id && t.Activo);
            ViewBag.TurnoId = turno.Id;

            return View();
        }
    }
}
