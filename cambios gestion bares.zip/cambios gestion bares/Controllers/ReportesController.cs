﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using GestionBares.Utils;
using GestionBares.Data;
using GestionBares.ViewModels;
using Microsoft.AspNetCore.Mvc.Rendering;
using GestionBares.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using System.Drawing;
using GestionBares.Models.AlmacenModels;

namespace GestionBares.Controllers
{
    [Authorize(Roles = DefinicionRoles.AmasB)]
    public class ReportesController : Controller
    {

        private readonly ApplicationDbContext _context;
        private readonly AlmacenDbContext _almacen;

        public ReportesController(ApplicationDbContext context, AlmacenDbContext almacen)
        {
            _context = context;
            _almacen = almacen;
        }

        //public IActionResult CostosVentasBares()
        //{
        //    ViewBag.Bares = new MultiSelectList(_context.Set<Bar>().ToList(), "Id", "Nombre");
        //    ViewBag.FormaDePeriodo = new SelectList(Enum.GetValues(typeof(FormaDePeriodo)));
        //    return View();
        //}

        //[HttpPost]
        //public IActionResult CostosVentasBares(ParametrosVM parametros)
        //{
        //    var existenciaService = new ExistenciasService(_context);
        //    var colors = GetColor();
        //    var turnosEnPeriodo = _context.Set<Turno>().Where(t => t.FechaInicio >= parametros.FechaInicio && t.FechaInicio <= parametros.FechaFin).ToList();
        //    var index = 0;
        //    var labels = turnosEnPeriodo.OrderBy(t => t.FechaInicio).GroupBy(t => t.FechaInicio.Date).Select(t => t.Key.ToShortDateString()).ToList();
        //    var datosCosto = new DatosGraficas()
        //    {
        //        Labels = labels,
        //    };
        //    var datosVentas = new DatosGraficas()
        //    {
        //        Labels = labels,
        //    };
        //    index = 0;
        //    foreach (var barId in parametros.Bares)
        //    {
        //        var bar = _context.Set<Bar>().Find(barId);
        //        var ventas = new List<ResumenVentas>();
        //        foreach (var turno in turnosEnPeriodo.Where(t => t.BarId == barId))
        //        {
        //            var resumen = existenciaService.ExistenciaVentaDeBarPorTurno(turno.Id).ToList();
        //            ventas.Add(new ResumenVentas
        //            {
        //                TurnoId = turno.Id,
        //                Fecha = turno.FechaInicio.Date,
        //                Ventas = resumen.Sum(e => e.Consumo * (double)e.Precio),
        //                Costos = resumen.Sum(e => e.Consumo * (double)e.Costo),
        //            });
        //        }
        //        ventas = ventas.GroupBy(v => v.Fecha).Select(v => new ResumenVentas
        //        {
        //            Fecha = v.Key,
        //            Ventas = v.Sum(r => r.Ventas),
        //            Costos = v.Sum(r => r.Costos)
        //        }).ToList();
        //        datosVentas.Datasets.Add(new Dataset
        //        {
        //            Label = bar.Nombre,
        //            BackgroundColor = colors[index],
        //            BorderColor = colors[index],
        //            Fill = false,
        //            Data = labels.Select(c => ventas.Any(d => d.Fecha.ToShortDateString() == c) ? ventas.Where(d => d.Fecha.ToShortDateString() == c).Sum(s => s.Ventas) : 0).ToList()
        //        });
        //        datosCosto.Datasets.Add(new Dataset
        //        {
        //            Label = bar.Nombre,
        //            BackgroundColor = colors[index],
        //            BorderColor = colors[index],
        //            Fill = false,
        //            Data = labels.Select(c => ventas.Any(d => d.Fecha.ToShortDateString() == c) ? ventas.Where(d => d.Fecha.ToShortDateString() == c).Sum(s => s.Costos) : 0).ToList()
        //        });
        //        index++;
        //    }
        //    ViewBag.Costos = datosCosto;
        //    ViewBag.Ventas = datosVentas;
        //    ViewBag.Bares = new MultiSelectList(_context.Set<Bar>().ToList(), "Id", "Nombre", parametros.Bares);
        //    ViewBag.FormaDePeriodo = new SelectList(Enum.GetValues(typeof(FormaDePeriodo)), parametros.FormaDePeriodo);
        //    return View(parametros);
        //}

        // GET: Reportes2
        public IActionResult ReportesPorBar()
        {
            ReportePorBar2 reportePorBar2 = new ReportePorBar2();
            reportePorBar2.FechaInicio = DateTime.Now;
            reportePorBar2.FechaFin = DateTime.Now;

            ViewData["Bares"] = new SelectList(_context.Bares.ToList(), "Id", "Nombre");



            return View(reportePorBar2);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ReportesPorBar([Bind("BarId, FechaInicio, FechaFin, EsDeBar")] ReportePorBar2 reportePorBar2)
        {

            try
            {

                return RedirectToAction("Interfaz", reportePorBar2);
            }
            catch
            {
                return View();
            }
        }

        public IActionResult Interfaz(ReportePorBar2 reportePorBar2)
        {

            try
            {

                //Trayendo todos los turnos
                reportePorBar2.FechaFin = reportePorBar2.FechaFin.AddHours(23);
                reportePorBar2.FechaFin = reportePorBar2.FechaFin.AddMinutes(59);
                reportePorBar2.FechaFin = reportePorBar2.FechaFin.AddSeconds(59);

                if (reportePorBar2.EsDeBar)
                {
                    var Turnos = _context.Turnos.Include(c => c.Dependiente)
                .Where(c => c.BarId == reportePorBar2.BarId
                && c.FechaInicio >= reportePorBar2.FechaInicio
                && c.FechaFin <= reportePorBar2.FechaFin
                && c.Activo == false).ToList();
                    ViewData["Bar"] = _context.Bares.SingleOrDefault(c => c.Id == reportePorBar2.BarId).Nombre;
                    return View("ReporteXBares", Turnos);
                }

                else
                {
                    var Turnos = _context.Turnos.Include(c => c.Bar)
                    .Where(c => c.DependienteId == reportePorBar2.DependienteId
                    && c.FechaInicio >= reportePorBar2.FechaInicio
                    && c.FechaFin <= reportePorBar2.FechaFin
                    && c.Activo == false).ToList();
                    ViewData["Dependiente"] = _context.Dependientes.SingleOrDefault(c => c.Id == reportePorBar2.DependienteId).Nombres;
                    return View("ReporteXDependientes", Turnos);
                }

            }
            catch
            {
                return View();
            }
        }

        public IActionResult ReportesPorDependiente()
        {
            ReportePorBar2 reportePorBar2 = new ReportePorBar2();
            reportePorBar2.FechaInicio = DateTime.Now;
            reportePorBar2.FechaFin = DateTime.Now;

            ViewData["Dependientes"] = new SelectList(_context.Dependientes.ToList(), "Id", "Nombres");
            return View(reportePorBar2);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ReportesPorDependiente([Bind("DependienteId, FechaInicio, FechaFin, EsDeBar")] ReportePorBar2 reportePorBar2)
        {

            try
            {

                return RedirectToAction("Interfaz", reportePorBar2);
            }
            catch
            {
                return View();
            }
        }



        public IActionResult Detalles(int id, bool mostrar)
        {

            var Turno = _context.Turnos.Include(c => c.Dependiente).Include(c => c.Bar).SingleOrDefault(c => c.Id == id);
            var ControlExistencia = _context.ControlesDeExistencias.SingleOrDefault(c => c.TurnoId == Turno.Id);

            var DetallesExistencia = _context.DetallesControlesDeExistencias.Include(c => c.Producto)
                .Where(c => c.ControlId == ControlExistencia.Id).ToList();



            List<ReporteIPV> reporteIPVs = new List<ReporteIPV>();
            CalcularConsumo calcularConsumo = new CalcularConsumo(_context);

            foreach (var item in DetallesExistencia)
            {
                reporteIPVs.Add(new ReporteIPV()
                {
                    Codigo = item.Producto.Codigo,
                    Costo = item.Producto.Costo,
                    Descripcion = item.Producto.Nombre,
                    Final = item.Cantidad,
                    Consumo = item.Consumo
                });


                if (_context.Turnos.Any((c => c.BarId == Turno.BarId && c.Id != id && c.Activo == false)))
                {
                    var TurnoAnterior = _context.Turnos.OrderBy(c => c.FechaFin).Where(c => c.BarId == Turno.BarId && c.Id != id && c.Activo == false).Last();
                    var ControlAnterior = _context.ControlesDeExistencias.Where(c => c.TurnoId == TurnoAnterior.Id).Single();

                    if (_context.Turnos.Any(c => c.BarId == Turno.BarId && c.Id != id && c.Activo == false))
                        reporteIPVs.Last().Inicio = _context.DetallesControlesDeExistencias.Where(c => c.ProductoId == item.ProductoId &&
                        c.ControlId == ControlAnterior.Id).Single().Cantidad;
                    else
                        reporteIPVs.Last().Inicio = 0;
                }

                if (_context.EntregasDeAlmacen.Any(c => c.TurnoId == id && c.ProductoId == item.ProductoId))
                    foreach (var Entradas in _context.EntregasDeAlmacen.Where(c => c.TurnoId == id && c.ProductoId == item.ProductoId).ToList())
                        reporteIPVs.Last().Entradas += Entradas.Cantidad;
                else
                    reporteIPVs.Last().Entradas = 0;
                if (_context.Traslados.Any(c => c.TurnoId == id))
                    foreach (var Traslados in _context.Traslados.Where(c => c.TurnoId == id && c.ProductoId == item.ProductoId).ToList())
                        reporteIPVs.Last().TrasladosNegativos += Traslados.Cantidad;
                else
                    reporteIPVs.Last().TrasladosNegativos = 0;
                if (_context.Traslados.Any(c => c.DestinoId == id && c.ProductoId == item.ProductoId))
                    foreach (var Traslados in _context.Traslados.Where(c => c.DestinoId == id && c.ProductoId == item.ProductoId).ToList())
                        reporteIPVs.Last().TrasladosPositivos += Traslados.Cantidad;
                else
                    reporteIPVs.Last().TrasladosPositivos = 0;
            }
            ViewData["LimiteConsumo"] = Turno.LimiteDeIndice;
            ViewData["IndiceConsumo"] = Turno.IndiceDeConsumo;
            ViewData["Bar"] = Turno.Bar.Nombre;
            ViewData["Dependiente"] = Turno.Dependiente.Nombres;
            ViewData["InicioDelTurno"] = Turno.FechaInicio.ToString();
            ViewData["FinDelTurno"] = Turno.FechaFin.ToString();
            ViewData["Mostrar"] = mostrar;

            return View(reporteIPVs);
        }


        public IActionResult CostosVentasBares()
        {
            ParametrosVM parametros = new ParametrosVM();
            parametros.Mostrar = "Consumo";
            parametros.MostrarVentas = "Cantidad";
            parametros.FechaInicio = DateTime.Now;
            parametros.FechaFin = DateTime.Now;

            ViewBag.Bares = new MultiSelectList(_context.Set<Bar>().ToList(), "Id", "Nombre");
            ViewBag.FormaDePeriodo = new SelectList(Enum.GetValues(typeof(FormaDePeriodo)));

            return View(parametros);
        }

        [HttpPost]
        public IActionResult CostosVentasBares(ParametrosVM parametros)
        {

            var existenciaService = new ExistenciasService(_context);
            var colors = GetColor();

            var turnosEnPeriodo = _context.Set<Turno>()
                .Where(t => t.FechaInicio >= parametros.FechaInicio && t.FechaInicio <= parametros.FechaFin)
                .OrderBy(c => c.FechaInicio)
                .ToList();
            var index = 0;

            List<string> labels = new List<string>();
            foreach (var item in turnosEnPeriodo)
            {
                if (labels.Count != 0)
                {
                    if (labels.Last() != item.FechaInicio.ToShortDateString())
                        labels.Add(item.FechaInicio.ToShortDateString());
                }
                else
                    labels.Add(item.FechaInicio.ToShortDateString());
            }

            var datosCosto = new DatosGraficas()
            {
                Labels = labels,
            };
            var datosVentas = new DatosGraficas()
            {
                Labels = labels,
            };

            index = 0;
            double contador = 0;
            double contadorVentas = 0;
            var TurnoAnterior = new Turno();

            foreach (var barId in parametros.Bares)
            {
                datosCosto.Datasets.Add(new Dataset()
                {
                    BackgroundColor = colors[index],
                    BorderColor = colors[index],
                    Label = _context.Bares.SingleOrDefault(c => c.Id == barId).Nombre,
                    Fill = false,
                });

                datosVentas.Datasets.Add(new Dataset()
                {
                    BackgroundColor = datosCosto.Datasets.Last().BackgroundColor,
                    BorderColor = datosCosto.Datasets.Last().BorderColor,
                    Label = datosCosto.Datasets.Last().Label,
                    Fill = false,
                });
                var datos = turnosEnPeriodo
                    .Where(c => c.BarId == barId)
                    .GroupBy(t => t.FechaInicio.ToShortDateString())
                    .Select(t => new
                    {

                    });

                foreach (var label in datosCosto.Labels)
                {
                    int CantidadClientes = 0;
                    foreach (var turno in turnosEnPeriodo.Where(c => c.FechaInicio.ToShortDateString() == label && c.BarId == barId))
                    {
                        var detalles = _context.DetallesControlesDeExistencias
                            .Include(c => c.Producto)
                            .Include(c => c.Control)
                            .Where(c => c.Control.TurnoId == turno.Id)
                            .ToList();
                        foreach (var Detalles in detalles)
                        {
                            if (parametros.Mostrar == "Indice Gasto/Cliente")
                            {
                                contador += Detalles.Consumo * Detalles.Costo;
                            }
                            else
                            {
                                contador += Detalles.Consumo;
                            }

                        }
                        var detallesVentas = _context.DetallesControlesDeExistenciasVenta
                            .Include(c => c.Producto)
                            .Include(c => c.Control)
                            .Where(c => c.Control.TurnoId == turno.Id)
                            .ToList();
                        foreach (var Detalles in detallesVentas)
                        {
                            if (parametros.MostrarVentas == "Cantidad")
                            {
                                contadorVentas += Detalles.Consumo;
                            }
                            else
                            {
                                contadorVentas += Detalles.Consumo * (double)Detalles.Precio;
                            }
                        }
                        CantidadClientes = _almacen.Ocupacion.SingleOrDefault(c => c.Fecha.ToShortDateString() == turno.FechaInicio.ToShortDateString()).OcupacionDelDia;
                    }
                    if (turnosEnPeriodo.Any(c => c.FechaInicio.ToShortDateString() == label && c.BarId == barId))
                    {
                        if (parametros.Mostrar == "Indice Gasto/Cliente")
                        {
                            datosCosto.Datasets.Last().Data.Add(contador / CantidadClientes);
                        }
                        else
                        {
                            datosCosto.Datasets.Last().Data.Add(contador);
                        }
                        datosVentas.Datasets.Last().Data.Add(contadorVentas);
                        contadorVentas = 0;
                        contador = 0;
                    }
                    else
                    {
                        datosCosto.Datasets.Last().Data.Add(null);
                        datosVentas.Datasets.Last().Data.Add(null);
                    }
                }

                index++;
                TurnoAnterior = new Turno();
                TurnoAnterior.FechaInicio = new DateTime(1, 1, 1);
            }

            ViewBag.Costos = datosCosto;
            ViewBag.Ventas = datosVentas;
            ViewBag.Bares = new MultiSelectList(_context.Set<Bar>().ToList(), "Id", "Nombre", parametros.Bares);
            ViewBag.FormaDePeriodo = new SelectList(Enum.GetValues(typeof(FormaDePeriodo)), parametros.FormaDePeriodo);
            return View(parametros);
        }

        public IActionResult CostosVentasDependientes()
        {
            ParametrosVM parametros = new ParametrosVM();
            parametros.Mostrar = "Consumo";
            parametros.MostrarVentas = "Cantidad";
            parametros.FechaInicio = DateTime.Now;
            parametros.FechaFin = DateTime.Now;

            ViewBag.Dependientes = new MultiSelectList(_context.Set<Dependiente>().ToList(), "Id", "Nombres");
            ViewBag.FormaDePeriodo = new SelectList(Enum.GetValues(typeof(FormaDePeriodo)));

            return View(parametros);
        }

        [HttpPost]
        public IActionResult CostosVentasDependientes(ParametrosVM parametros)
        {

            var existenciaService = new ExistenciasService(_context);
            var colors = GetColor();

            var turnosEnPeriodo = _context.Set<Turno>()
                .Where(t => t.FechaInicio >= parametros.FechaInicio && t.FechaInicio <= parametros.FechaFin)
                .OrderBy(c => c.FechaInicio)
                .ToList();
            var index = 0;

            List<string> labels = new List<string>();
            foreach (var item in turnosEnPeriodo)
            {
                if (labels.Count != 0)
                {
                    if (labels.Last() != item.FechaInicio.ToShortDateString())
                        labels.Add(item.FechaInicio.ToShortDateString());
                }
                else
                    labels.Add(item.FechaInicio.ToShortDateString());
            }

            var datosCosto = new DatosGraficas()
            {
                Labels = labels,
            };
            var datosVentas = new DatosGraficas()
            {
                Labels = labels,
            };

            index = 0;
            double contador = 0;
            double contadorVentas = 0;
            var TurnoAnterior = new Turno();

            foreach (var DependienteId in parametros.Dependientes)
            {
                datosCosto.Datasets.Add(new Dataset()
                {
                    BackgroundColor = colors[index],
                    BorderColor = colors[index],
                    Label = _context.Dependientes.SingleOrDefault(c => c.Id == DependienteId).Nombres,
                    Fill = false,
                });

                datosVentas.Datasets.Add(new Dataset()
                {
                    BackgroundColor = datosCosto.Datasets.Last().BackgroundColor,
                    BorderColor = datosCosto.Datasets.Last().BorderColor,
                    Label = datosCosto.Datasets.Last().Label,
                    Fill = false,
                });

                foreach (var label in datosCosto.Labels)
                {
                    int CantidadClientes = 0;
                    foreach (var turno in turnosEnPeriodo.Where(c => c.FechaInicio.ToShortDateString() == label && c.DependienteId == DependienteId))
                    {
                        var detalles = _context.DetallesControlesDeExistencias
                            .Include(c => c.Control)
                            .Include(c => c.Producto)
                            .Where(c => c.Control.TurnoId == turno.Id)
                            .ToList();
                        foreach (var Detalles in detalles)
                        {
                            if (parametros.Mostrar == "Indice Gasto/Cliente")
                            {
                                contador += Detalles.Consumo * Detalles.Costo;
                            }
                            else
                            {
                                contador += Detalles.Consumo;
                            }

                        }
                        var detallesVentas = _context.DetallesControlesDeExistenciasVenta
                            .Include(c => c.Producto)
                            .Include(c => c.Control)
                            .Where(c => c.Control.TurnoId == turno.Id)
                            .ToList();
                        foreach (var Detalles in detallesVentas)
                        {
                            if (parametros.MostrarVentas == "Cantidad")
                            {
                                contadorVentas += Detalles.Consumo;
                            }
                            else
                            {
                                contadorVentas += Detalles.Consumo * (double)Detalles.Precio;
                            }
                        }
                        CantidadClientes = _almacen.Ocupacion.SingleOrDefault(c => c.Fecha.ToShortDateString() == turno.FechaInicio.ToShortDateString()).OcupacionDelDia;
                    }
                    if (turnosEnPeriodo.Any(c => c.FechaInicio.ToShortDateString() == label && c.DependienteId == DependienteId))
                    {
                        if (parametros.Mostrar == "Indice Gasto/Cliente")
                        {
                            datosCosto.Datasets.Last().Data.Add(contador / CantidadClientes);
                        }
                        else
                        {
                            datosCosto.Datasets.Last().Data.Add(contador);
                        }
                        datosVentas.Datasets.Last().Data.Add(contadorVentas);
                        contadorVentas = 0;
                        contador = 0;
                    }
                    else
                    {
                        datosCosto.Datasets.Last().Data.Add(null);
                        datosVentas.Datasets.Last().Data.Add(null);
                    }
                }

                index++;
                TurnoAnterior = new Turno();
                TurnoAnterior.FechaInicio = new DateTime(1, 1, 1);
            }

            ViewBag.Costos = datosCosto;
            ViewBag.Ventas = datosVentas;
            ViewBag.Dependientes = new MultiSelectList(_context.Set<Dependiente>().ToList(), "Id", "Nombres", parametros.Dependientes);
            ViewBag.FormaDePeriodo = new SelectList(Enum.GetValues(typeof(FormaDePeriodo)), parametros.FormaDePeriodo);
            return View(parametros);
        }

        public IActionResult CostosVentasProductos()
        {
            ParametrosVM parametros = new ParametrosVM();
            parametros.Mostrar = "Consumo";
            parametros.MostrarVentas = "Cantidad";
            parametros.FechaInicio = DateTime.Now;
            parametros.FechaFin = DateTime.Now;

            ViewBag.Productos = new MultiSelectList(_context.Set<Producto>().ToList(), "Id", "Nombre");
            ViewBag.FormaDePeriodo = new SelectList(Enum.GetValues(typeof(FormaDePeriodo)));

            return View(parametros);
        }

        [HttpPost]
        public IActionResult CostosVentasProductos(ParametrosVM parametros)
        {

            var existenciaService = new ExistenciasService(_context);
            var colors = GetColor();

            var turnosEnPeriodo = _context.Set<Turno>()
                .Where(t => t.FechaInicio >= parametros.FechaInicio && t.FechaInicio <= parametros.FechaFin)
                .OrderBy(c => c.FechaInicio)
                .ToList();
            var index = 0;

            List<string> labels = new List<string>();
            foreach (var item in turnosEnPeriodo)
            {
                if (labels.Count != 0)
                {
                    if (labels.Last() != item.FechaInicio.ToShortDateString())
                        labels.Add(item.FechaInicio.ToShortDateString());
                }
                else
                    labels.Add(item.FechaInicio.ToShortDateString());
            }

            var datosCosto = new DatosGraficas()
            {
                Labels = labels,
            };
            var datosVentas = new DatosGraficas()
            {
                Labels = labels,
            };

            index = 0;
            double contador = 0;
            double contadorVentas = 0;
            var TurnoAnterior = new Turno();

            foreach (var productoId in parametros.Productos)
            {
                datosCosto.Datasets.Add(new Dataset()
                {
                    BackgroundColor = colors[index],
                    BorderColor = colors[index],
                    Label = _context.Productos.SingleOrDefault(c => c.Id == productoId).Nombre,
                    Fill = false,
                });

                datosVentas.Datasets.Add(new Dataset()
                {
                    BackgroundColor = datosCosto.Datasets.Last().BackgroundColor,
                    BorderColor = datosCosto.Datasets.Last().BorderColor,
                    Label = datosCosto.Datasets.Last().Label,
                    Fill = false,
                });

                foreach (var label in datosCosto.Labels)
                {
                    int CantidadClientes = 0;
                    foreach (var turno in turnosEnPeriodo.Where(c => c.FechaInicio.ToShortDateString() == label))
                    {
                        if (parametros.Mostrar == "Indice Gasto/Cliente")
                        {
                            contador += _context.DetallesControlesDeExistencias
                            .Include(c => c.Control)
                            .Where(c => c.Control.TurnoId == turno.Id && c.ProductoId == productoId)
                            .Sum(c => c.Consumo * c.Costo);
                        }
                        else
                        {
                            contador += _context.DetallesControlesDeExistencias
                            .Include(c => c.Control)
                            .Where(c => c.Control.TurnoId == turno.Id && c.ProductoId == productoId)
                            .Sum(c => c.Consumo);
                        }
                        if (parametros.MostrarVentas == "Cantidad")
                        {
                            contadorVentas += _context.DetallesControlesDeExistenciasVenta
                            .Include(c => c.Control)
                            .Where(c => c.Control.TurnoId == turno.Id && c.ProductoId == productoId)
                            .Sum(c => c.Consumo);
                        }
                        else
                        {
                            contadorVentas += _context.DetallesControlesDeExistenciasVenta
                            .Include(c => c.Control)
                            .Where(c => c.Control.TurnoId == turno.Id && c.ProductoId == productoId)
                            .Sum(c => c.Consumo * (double)c.Precio);
                        }
                        CantidadClientes = _almacen.Ocupacion.SingleOrDefault(c => c.Fecha.ToShortDateString() == turno.FechaInicio.ToShortDateString()).OcupacionDelDia;
                    }
                    if (turnosEnPeriodo.Any(c => c.FechaInicio.ToShortDateString() == label))
                    {
                        if (parametros.Mostrar == "Indice Gasto/Cliente")
                        {
                            datosCosto.Datasets.Last().Data.Add(contador / CantidadClientes);
                        }
                        else
                        {
                            datosCosto.Datasets.Last().Data.Add(contador);
                        }
                        datosVentas.Datasets.Last().Data.Add(contadorVentas);
                        contadorVentas = 0;
                        contador = 0;
                    }
                    else
                    {
                        datosCosto.Datasets.Last().Data.Add(null);
                        datosVentas.Datasets.Last().Data.Add(null);
                    }
                }

                index++;
                TurnoAnterior = new Turno();
                TurnoAnterior.FechaInicio = new DateTime(1, 1, 1);
            }

            ViewBag.Costos = datosCosto;
            ViewBag.Ventas = datosVentas;
            ViewBag.Productos = new MultiSelectList(_context.Set<Producto>().ToList(), "Id", "Nombre", parametros.Productos);
            ViewBag.FormaDePeriodo = new SelectList(Enum.GetValues(typeof(FormaDePeriodo)), parametros.FormaDePeriodo);
            return View(parametros);
        }

        //public IActionResult CostosVentasProductos()
        //{
        //    ParametrosVM parametros = new ParametrosVM();
        //    parametros.Mostrar = "Consumo";
        //    parametros.MostrarVentas = "Cantidad";
        //    parametros.FechaInicio = DateTime.Now;
        //    parametros.FechaFin = DateTime.Now;

        //    ViewBag.Productos = new MultiSelectList(_context.Set<Producto>().ToList(), "Id", "Nombre");
        //    ViewBag.FormaDePeriodo = new SelectList(Enum.GetValues(typeof(FormaDePeriodo)));

        //    return View(parametros);
        //}

        //[HttpPost]
        //public IActionResult CostosVentasProductos(ParametrosVM parametros)
        //{

        //var existenciaService = new ExistenciasService(_context);
        //var colors = GetColor();



        //var turnosEnPeriodo = _context.Set<Turno>().OrderBy(c => c.FechaInicio).Where(t => t.FechaInicio >= parametros.FechaInicio && t.FechaInicio <= parametros.FechaFin).ToList();
        //var index = 0;

        //List<string> labels = new List<string>();
        //foreach (var item in turnosEnPeriodo)
        //{
        //    if (labels.Count != 0)
        //    {
        //        if (labels.Last() != item.FechaInicio.ToShortDateString())
        //            labels.Add(item.FechaInicio.ToShortDateString());
        //    }
        //    else
        //        labels.Add(item.FechaInicio.ToShortDateString());
        //}

        //var datosCosto = new DatosGraficas()
        //{
        //    Labels = labels,
        //};
        //var datosVentas = new DatosGraficas()
        //{
        //    Labels = labels,
        //};

        //index = 0;
        //double contador = 0;
        //double contadorVentas = 0;
        //var TurnoAnterior = new Turno();

        //foreach (var DependienteId in parametros.Dependientes)
        //{
        //    datosCosto.Datasets.Add(new Dataset()
        //    {
        //        BackgroundColor = colors[index],
        //        BorderColor = colors[index],
        //        Label = _context.Dependientes.SingleOrDefault(c => c.Id == DependienteId).Nombres,
        //        Fill = false,
        //    });

        //    datosVentas.Datasets.Add(new Dataset()
        //    {
        //        BackgroundColor = datosCosto.Datasets.Last().BackgroundColor,
        //        BorderColor = datosCosto.Datasets.Last().BorderColor,
        //        Label = datosCosto.Datasets.Last().Label,
        //        Fill = false,
        //    });

        //    foreach (var label in datosCosto.Labels)
        //    {
        //        int CantidadClientes = 0;
        //        foreach (var turno in turnosEnPeriodo.Where(c => c.FechaInicio.ToShortDateString() == label && c.DependienteId == DependienteId))
        //        {
        //            foreach (var Detalles in _context.DetallesControlesDeExistencias.Include(c => c.Producto).Where(c => c.ControlId ==
        //             _context.ControlesDeExistencias.SingleOrDefault(t => t.TurnoId == turno.Id).Id).ToList())
        //            {
        //                if (parametros.Mostrar == "Indice Gasto/Cliente")
        //                {
        //                    contador += Detalles.Consumo * Detalles.Costo;
        //                }
        //                else
        //                {
        //                    contador += Detalles.Consumo;
        //                }

        //            }
        //            foreach (var Detalles in _context.DetallesControlesDeExistenciasVenta.Include(c => c.Producto).Where(c => c.ControlId ==
        //             _context.ControlesDeExistenciasVenta.SingleOrDefault(t => t.TurnoId == turno.Id).Id).ToList())
        //            {
        //                if (parametros.MostrarVentas == "Cantidad")
        //                {
        //                    contadorVentas += Detalles.Consumo;
        //                }
        //                else
        //                {
        //                    contadorVentas += Detalles.Consumo * (double)Detalles.Precio;
        //                }
        //            }
        //            CantidadClientes = _almacen.Ocupacion.SingleOrDefault(c => c.Fecha.ToShortDateString() == turno.FechaInicio.ToShortDateString()).OcupacionDelDia;
        //        }
        //        if (turnosEnPeriodo.Any(c => c.FechaInicio.ToShortDateString() == label && c.DependienteId == DependienteId))
        //        {
        //            if (parametros.Mostrar == "Indice Gasto/Cliente")
        //            {
        //                datosCosto.Datasets.Last().Data.Add(contador / CantidadClientes);
        //            }
        //            else
        //            {
        //                datosCosto.Datasets.Last().Data.Add(contador);
        //            }
        //            datosVentas.Datasets.Last().Data.Add(contadorVentas);
        //            contadorVentas = 0;
        //            contador = 0;
        //        }
        //        else
        //        {
        //            datosCosto.Datasets.Last().Data.Add(null);
        //            datosVentas.Datasets.Last().Data.Add(null);
        //        }
        //    }

        //    index++;
        //    TurnoAnterior = new Turno();
        //    TurnoAnterior.FechaInicio = new DateTime(1, 1, 1);
        //}

        //ViewBag.Costos = datosCosto;
        //ViewBag.Ventas = datosVentas;
        //ViewBag.Dependientes = new MultiSelectList(_context.Set<Dependiente>().ToList(), "Id", "Nombres", parametros.Dependientes);
        //ViewBag.FormaDePeriodo = new SelectList(Enum.GetValues(typeof(FormaDePeriodo)), parametros.FormaDePeriodo);
        //return View(parametros);
        //}

        private List<string> GetColor()
        {
            const int DELTA_PERCENT = 10;
            List<Color> alreadyChoosenColors = new List<Color>();

            // initialize the random generator
            Random r = new Random();

            for (int i = 0; i < 30; i++)
            {
                bool chooseAnotherColor = true;
                Color tmpColor = Color.FromArgb(0, 0, 0);
                while (chooseAnotherColor)
                {
                    // create a random color by generating three random channels
                    //
                    int redColor = r.Next(0, 255);
                    int greenColor = r.Next(0, 255);
                    int blueColor = r.Next(0, 255);
                    tmpColor = Color.FromArgb(redColor, greenColor, blueColor);

                    // check if a similar color has already been created
                    //
                    chooseAnotherColor = false;
                    foreach (Color c in alreadyChoosenColors)
                    {
                        int delta = c.R * DELTA_PERCENT / 100;
                        if (c.R - delta <= tmpColor.R && tmpColor.R <= c.R + delta)
                        {
                            chooseAnotherColor = true;
                            break;
                        }

                        delta = c.G * DELTA_PERCENT / 100;
                        if (c.G - delta <= tmpColor.G && tmpColor.G <= c.G + delta)
                        {
                            chooseAnotherColor = true;
                            break;
                        }

                        delta = c.B * DELTA_PERCENT / 100;
                        if (c.B - delta <= tmpColor.B && tmpColor.B <= c.B + delta)
                        {
                            chooseAnotherColor = true;
                            break;
                        }
                    }
                }

                alreadyChoosenColors.Add(tmpColor);
                // you can safely use the tmpColor here

            }
            var pallete = new List<Color>();
            return alreadyChoosenColors.Select(c => HexConverter(c)).ToList();
        }

        private String HexConverter(Color color)
        {
            return "#" + color.R.ToString("X2") + color.G.ToString("X2") + color.B.ToString("X2");
        }




        public IActionResult ReportesPorBarVentas()
        {
            ReportePorBar2 reportePorBar2 = new ReportePorBar2();
            reportePorBar2.FechaInicio = DateTime.Now;
            reportePorBar2.FechaFin = DateTime.Now;

            ViewData["Bares"] = new SelectList(_context.Bares.ToList(), "Id", "Nombre");



            return View(reportePorBar2);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ReportesPorBarVentas([Bind("BarId, FechaInicio, FechaFin, EsDeBar")] ReportePorBar2 reportePorBar2)
        {

            try
            {

                return RedirectToAction("InterfazVentas", reportePorBar2);
            }
            catch
            {
                return View();
            }
        }

        public IActionResult InterfazVentas(ReportePorBar2 reportePorBar2)
        {

            try
            {

                //Trayendo todos los turnos
                reportePorBar2.FechaFin = reportePorBar2.FechaFin.AddHours(23);
                reportePorBar2.FechaFin = reportePorBar2.FechaFin.AddMinutes(59);
                reportePorBar2.FechaFin = reportePorBar2.FechaFin.AddSeconds(59);

                if (reportePorBar2.EsDeBar)
                {
                    var Turnos = _context.Turnos.Include(c => c.Dependiente)
                .Where(c => c.BarId == reportePorBar2.BarId
                && c.FechaInicio >= reportePorBar2.FechaInicio
                && c.FechaFin <= reportePorBar2.FechaFin
                && c.Activo == false).ToList();
                    ViewData["Bar"] = _context.Bares.SingleOrDefault(c => c.Id == reportePorBar2.BarId).Nombre;
                    return View("ReporteXBaresVentas", Turnos);
                }

                else
                {
                    var Turnos = _context.Turnos.Include(c => c.Bar)
                    .Where(c => c.DependienteId == reportePorBar2.DependienteId
                    && c.FechaInicio >= reportePorBar2.FechaInicio
                    && c.FechaFin <= reportePorBar2.FechaFin
                    && c.Activo == false).ToList();
                    ViewData["Dependiente"] = _context.Dependientes.SingleOrDefault(c => c.Id == reportePorBar2.DependienteId).Nombres;
                    return View("ReporteXDependientesVentas", Turnos);
                }

            }
            catch
            {
                return View();
            }
        }

        public IActionResult ReportesPorDependienteVentas()
        {
            ReportePorBar2 reportePorBar2 = new ReportePorBar2();
            reportePorBar2.FechaInicio = DateTime.Now;
            reportePorBar2.FechaFin = DateTime.Now;

            ViewData["Dependientes"] = new SelectList(_context.Dependientes.ToList(), "Id", "Nombres");
            return View(reportePorBar2);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ReportesPorDependienteVentas([Bind("DependienteId, FechaInicio, FechaFin, EsDeBar")] ReportePorBar2 reportePorBar2)
        {

            try
            {

                return RedirectToAction("InterfazVentas", reportePorBar2);
            }
            catch
            {
                return View();
            }
        }


        public IActionResult DetallesVentas(int id, bool mostrar)
        {

            var Turno = _context.Turnos.Include(c => c.Dependiente).Include(c => c.Bar).SingleOrDefault(c => c.Id == id);
            var ControlExistencia = _context.ControlesDeExistenciasVenta.SingleOrDefault(c => c.TurnoId == Turno.Id);

            var DetallesExistencia = _context.DetallesControlesDeExistenciasVenta.Include(c => c.Producto)
                .Where(c => c.ControlId == ControlExistencia.Id).ToList();



            List<ReporteIPV> reporteIPVs = new List<ReporteIPV>();
            CalcularConsumo calcularConsumo = new CalcularConsumo(_context);

            foreach (var item in DetallesExistencia)
            {
                reporteIPVs.Add(new ReporteIPV()
                {
                    Codigo = item.Producto.Codigo,
                    Costo = item.Producto.Costo,
                    Precio = item.Producto.Precio,
                    Descripcion = item.Producto.Nombre,
                    Final = item.Cantidad,
                    Consumo = item.Consumo
                });


                if (_context.Turnos.Any((c => c.BarId == Turno.BarId && c.Id != id && c.Activo == false)))
                {
                    var TurnoAnterior = _context.Turnos.OrderBy(c => c.FechaFin).Where(c => c.BarId == Turno.BarId && c.Id != id && c.Activo == false).Last();
                    var ControlAnterior = _context.ControlesDeExistenciasVenta.Where(c => c.TurnoId == TurnoAnterior.Id).Single();

                    if (_context.Turnos.Any(c => c.BarId == Turno.BarId && c.Id != id && c.Activo == false))
                        reporteIPVs.Last().Inicio = _context.DetallesControlesDeExistenciasVenta.Where(c => c.ProductoId == item.ProductoId &&
                        c.ControlId == ControlAnterior.Id).Single().Cantidad;
                    else
                        reporteIPVs.Last().Inicio = 0;
                }

                if (_context.EntregasDeAlmacenVenta.Any(c => c.TurnoId == id && c.ProductoId == item.ProductoId))
                    foreach (var Entradas in _context.EntregasDeAlmacenVenta.Where(c => c.TurnoId == id && c.ProductoId == item.ProductoId).ToList())
                        reporteIPVs.Last().Entradas += Entradas.Cantidad;
                else
                    reporteIPVs.Last().Entradas = 0;
                if (_context.TrasladosVenta.Any(c => c.TurnoId == id))
                    foreach (var Traslados in _context.TrasladosVenta.Where(c => c.TurnoId == id && c.ProductoId == item.ProductoId).ToList())
                        reporteIPVs.Last().TrasladosNegativos += Traslados.Cantidad;
                else
                    reporteIPVs.Last().TrasladosNegativos = 0;
                if (_context.TrasladosVenta.Any(c => c.DestinoId == id && c.ProductoId == item.ProductoId))
                    foreach (var Traslados in _context.TrasladosVenta.Where(c => c.DestinoId == id && c.ProductoId == item.ProductoId).ToList())
                        reporteIPVs.Last().TrasladosPositivos += Traslados.Cantidad;
                else
                    reporteIPVs.Last().TrasladosPositivos = 0;
            }
            ViewData["LimiteConsumo"] = Turno.LimiteDeIndice;
            ViewData["IndiceConsumo"] = Turno.IndiceDeConsumo;
            ViewData["Bar"] = Turno.Bar.Nombre;
            ViewData["Dependiente"] = Turno.Dependiente.Nombres;
            ViewData["InicioDelTurno"] = Turno.FechaInicio.ToString();
            ViewData["FinDelTurno"] = Turno.FechaFin.ToString();
            ViewData["Mostrar"] = mostrar;

            return View(reporteIPVs);
        }


    }





}