namespace GestionBares.ViewModels
{
    public class NotificacionVM
    {
        public string Descripcion { get; set; }
        public string Url { get; set; }
    }
}